"""3D Model
==========
Contains functions for creating 3D models of gross specimen. Code is being refactored into another repository, to be released."""
